interface proginter {
    String getString(String surname); // Изменяем параметр на String
}
